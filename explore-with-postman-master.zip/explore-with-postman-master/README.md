# explore-with-postman
A forked copy of Amber Race's Test Automation University course code, to accompany Beth Marshall's Test Automation University Course, "API Test Automation With Postman".

You can discover more of Amber's amazing code for API exploratory testing on her github page here: https://github.com/ambertests
